/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/10791/Desktop/P5_class1/P5_class1/P5_code/Comparator.v";
static unsigned int ng1[] = {1U, 0U};
static unsigned int ng2[] = {4U, 0U};



static void Cont_29_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t36[8];
    char t55[8];
    char t56[8];
    char t59[8];
    char t94[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    char *t35;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    char *t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t57;
    char *t58;
    char *t60;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    char *t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    char *t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    char *t92;
    char *t93;
    char *t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    char *t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    unsigned int t114;
    unsigned int t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    char *t119;
    unsigned int t120;
    unsigned int t121;
    char *t122;

LAB0:    t1 = (t0 + 2848U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 1368U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t2 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t4, 0, 8);
    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t22) != 0)
        goto LAB10;

LAB11:    t29 = (t4 + 4);
    t30 = *((unsigned int *)t4);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB12;

LAB13:    t51 = *((unsigned int *)t4);
    t52 = (~(t51));
    t53 = *((unsigned int *)t29);
    t54 = (t52 || t53);
    if (t54 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t29) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t55, 8);

LAB20:    t109 = (t0 + 3248);
    t110 = (t109 + 56U);
    t111 = *((char **)t110);
    t112 = (t111 + 56U);
    t113 = *((char **)t112);
    memset(t113, 0, 8);
    t114 = 1U;
    t115 = t114;
    t116 = (t3 + 4);
    t117 = *((unsigned int *)t3);
    t114 = (t114 & t117);
    t118 = *((unsigned int *)t116);
    t115 = (t115 & t118);
    t119 = (t113 + 4);
    t120 = *((unsigned int *)t113);
    *((unsigned int *)t113) = (t120 | t114);
    t121 = *((unsigned int *)t119);
    *((unsigned int *)t119) = (t121 | t115);
    xsi_driver_vfirst_trans(t109, 0, 0);
    t122 = (t0 + 3168);
    *((int *)t122) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t28 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB11;

LAB12:    t33 = (t0 + 1048U);
    t34 = *((char **)t33);
    t33 = (t0 + 1208U);
    t35 = *((char **)t33);
    memset(t36, 0, 8);
    t33 = (t34 + 4);
    t37 = (t35 + 4);
    t38 = *((unsigned int *)t34);
    t39 = *((unsigned int *)t35);
    t40 = (t38 ^ t39);
    t41 = *((unsigned int *)t33);
    t42 = *((unsigned int *)t37);
    t43 = (t41 ^ t42);
    t44 = (t40 | t43);
    t45 = *((unsigned int *)t33);
    t46 = *((unsigned int *)t37);
    t47 = (t45 | t46);
    t48 = (~(t47));
    t49 = (t44 & t48);
    if (t49 != 0)
        goto LAB22;

LAB21:    if (t47 != 0)
        goto LAB23;

LAB24:    goto LAB13;

LAB14:    t57 = (t0 + 1368U);
    t58 = *((char **)t57);
    t57 = ((char*)((ng2)));
    memset(t59, 0, 8);
    t60 = (t58 + 4);
    t61 = (t57 + 4);
    t62 = *((unsigned int *)t58);
    t63 = *((unsigned int *)t57);
    t64 = (t62 ^ t63);
    t65 = *((unsigned int *)t60);
    t66 = *((unsigned int *)t61);
    t67 = (t65 ^ t66);
    t68 = (t64 | t67);
    t69 = *((unsigned int *)t60);
    t70 = *((unsigned int *)t61);
    t71 = (t69 | t70);
    t72 = (~(t71));
    t73 = (t68 & t72);
    if (t73 != 0)
        goto LAB28;

LAB25:    if (t71 != 0)
        goto LAB27;

LAB26:    *((unsigned int *)t59) = 1;

LAB28:    memset(t56, 0, 8);
    t75 = (t59 + 4);
    t76 = *((unsigned int *)t75);
    t77 = (~(t76));
    t78 = *((unsigned int *)t59);
    t79 = (t78 & t77);
    t80 = (t79 & 1U);
    if (t80 != 0)
        goto LAB29;

LAB30:    if (*((unsigned int *)t75) != 0)
        goto LAB31;

LAB32:    t82 = (t56 + 4);
    t83 = *((unsigned int *)t56);
    t84 = *((unsigned int *)t82);
    t85 = (t83 || t84);
    if (t85 > 0)
        goto LAB33;

LAB34:    t88 = *((unsigned int *)t56);
    t89 = (~(t88));
    t90 = *((unsigned int *)t82);
    t91 = (t89 || t90);
    if (t91 > 0)
        goto LAB35;

LAB36:    if (*((unsigned int *)t82) > 0)
        goto LAB37;

LAB38:    if (*((unsigned int *)t56) > 0)
        goto LAB39;

LAB40:    memcpy(t55, t94, 8);

LAB41:    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 1, t36, 1, t55, 1);
    goto LAB20;

LAB18:    memcpy(t3, t36, 8);
    goto LAB20;

LAB22:    *((unsigned int *)t36) = 1;
    goto LAB24;

LAB23:    t50 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t50) = 1;
    goto LAB24;

LAB27:    t74 = (t59 + 4);
    *((unsigned int *)t59) = 1;
    *((unsigned int *)t74) = 1;
    goto LAB28;

LAB29:    *((unsigned int *)t56) = 1;
    goto LAB32;

LAB31:    t81 = (t56 + 4);
    *((unsigned int *)t56) = 1;
    *((unsigned int *)t81) = 1;
    goto LAB32;

LAB33:    t86 = (t0 + 1688U);
    t87 = *((char **)t86);
    goto LAB34;

LAB35:    t86 = (t0 + 1048U);
    t92 = *((char **)t86);
    t86 = (t0 + 1208U);
    t93 = *((char **)t86);
    memset(t94, 0, 8);
    t86 = (t92 + 4);
    t95 = (t93 + 4);
    t96 = *((unsigned int *)t92);
    t97 = *((unsigned int *)t93);
    t98 = (t96 ^ t97);
    t99 = *((unsigned int *)t86);
    t100 = *((unsigned int *)t95);
    t101 = (t99 ^ t100);
    t102 = (t98 | t101);
    t103 = *((unsigned int *)t86);
    t104 = *((unsigned int *)t95);
    t105 = (t103 | t104);
    t106 = (~(t105));
    t107 = (t102 & t106);
    if (t107 != 0)
        goto LAB45;

LAB42:    if (t105 != 0)
        goto LAB44;

LAB43:    *((unsigned int *)t94) = 1;

LAB45:    goto LAB36;

LAB37:    xsi_vlog_unsigned_bit_combine(t55, 1, t87, 1, t94, 1);
    goto LAB41;

LAB39:    memcpy(t55, t87, 8);
    goto LAB41;

LAB44:    t108 = (t94 + 4);
    *((unsigned int *)t94) = 1;
    *((unsigned int *)t108) = 1;
    goto LAB45;

}


extern void work_m_00000000003478682563_2319802268_init()
{
	static char *pe[] = {(void *)Cont_29_0};
	xsi_register_didat("work_m_00000000003478682563_2319802268", "isim/test_isim_beh.exe.sim/work/m_00000000003478682563_2319802268.didat");
	xsi_register_executes(pe);
}
